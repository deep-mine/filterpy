import numpy as np
import pytest


from harmattan.hawkairt.tracking.utils.bounding_box_metrics import (
    iou_batch,
    giou_batch,
    diou_batch,
    ciou_batch,
)

bboxes1_xysr = np.array([[5, 5, 100, 1]])
bboxes2_xysr = np.array([[15, 15, 100, 1]])
bboxes3_xysr = np.array([[10, 10, 100, 1]])

def test_iou_batch_identity():
    # identical boxes, IoU should be 1
    result = iou_batch(bboxes1_xysr, bboxes1_xysr)
    assert np.allclose(result, 1.0)

def test_iou_batch_no_overlap():
    # non-overlapping boxes, IoU should be 0
    result = iou_batch(bboxes1_xysr, bboxes2_xysr)
    assert np.allclose(result, 0.0)

def test_iou_batch_partial_overlap():
    result = iou_batch(bboxes1_xysr, bboxes3_xysr)
    assert result.shape == (1, 1)
    assert 0 < result[0, 0] < 1

def test_iou_batch_all_tests():
    bboxes_a = np.vstack((bboxes1_xysr, bboxes1_xysr, bboxes1_xysr))
    bboxes_b = np.vstack((bboxes1_xysr, bboxes2_xysr, bboxes3_xysr))
    result = iou_batch(bboxes_a, bboxes_b)
    assert result[0, 0] == 1.0  # identical
    assert result[0, 1] == 0.0  # no overlap
    assert 0 < result[0, 2] < 1.0  # partial overlap

def test_giou_batch_identity():
    result = giou_batch(bboxes1_xysr, bboxes1_xysr)
    assert np.allclose(result, 1.0)

def test_giou_batch_no_overlap():
    result = giou_batch(bboxes1_xysr, bboxes2_xysr)
    assert np.allclose(result, 0.5) or result[0, 0] < 0.5  # GIoU for no overlap is usually < 0.5

def test_giou_batch_partial_overlap():
    result = giou_batch(bboxes1_xysr, bboxes3_xysr)
    assert result.shape == (1, 1)
    assert 0 < result[0, 0] < 1

def test_giou_batch_all_tests():
    bboxes_a = np.vstack([bboxes1_xysr, bboxes1_xysr, bboxes1_xysr])
    bboxes_b = np.vstack([bboxes1_xysr, bboxes2_xysr, bboxes3_xysr])
    result = giou_batch(bboxes_a, bboxes_b)
    assert result[0, 0] == 1.0
    assert result[0, 1] < 0.5
    assert 0 < result[0, 2] < 1.0

def test_diou_batch_identity():
    result = diou_batch(bboxes1_xysr, bboxes1_xysr)
    assert np.allclose(result, 1.0)

def test_diou_batch_no_overlap():
    result = diou_batch(bboxes1_xysr, bboxes2_xysr)
    assert result[0, 0] < 0.5

def test_diou_batch_partial_overlap():
    result = diou_batch(bboxes1_xysr, bboxes3_xysr)
    assert result.shape == (1, 1)
    assert 0 < result[0, 0] < 1

def test_diou_batch_all_tests():
    bboxes_a = np.vstack([bboxes1_xysr, bboxes1_xysr, bboxes1_xysr])
    bboxes_b = np.vstack([bboxes1_xysr, bboxes2_xysr, bboxes3_xysr])
    result = diou_batch(bboxes_a, bboxes_b)
    assert result[0, 0] == 1.0
    assert result[0, 1] < 0.5
    assert 0 < result[0, 2] < 1.0

def test_ciou_batch_identity():
    result = ciou_batch(bboxes1_xysr, bboxes1_xysr)
    assert np.allclose(result, 1.0)

def test_ciou_batch_no_overlap():
    result = ciou_batch(bboxes1_xysr, bboxes2_xysr)
    assert result[0, 0] < 0.5

def test_ciou_batch_partial_overlap():
    result = ciou_batch(bboxes1_xysr, bboxes3_xysr)
    assert result.shape == (1, 1)
    assert 0 < result[0, 0] < 1

def test_ciou_batch_all_tests():
    bboxes_a = np.vstack([bboxes1_xysr, bboxes1_xysr, bboxes1_xysr])
    bboxes_b = np.vstack([bboxes1_xysr, bboxes2_xysr, bboxes3_xysr])
    result = ciou_batch(bboxes_a, bboxes_b)
    assert result[0, 0] == 1.0
    assert result[0, 1] < 0.5
    assert 0 < result[0, 2] < 1.0

