import numpy as np
import pytest

from harmattan.hawkairt.tracking.utils.bounding_box_conversion import (
    convert_bbox_xyxy_to_xysr as xyxy_to_xysr,
    convert_bbox_xysr_to_xyxy as xysr_to_xyxy,  
    convert_bbox_xyxy_to_xysr_batch,
    convert_bbox_xysr_to_xyxy_batch,
)

bboxes1_xyxy = np.array([[0, 0, 10, 10]])
bboxes2_xyxy = np.array([[10, 10, 20, 20]])
bboxes3_xyxy = np.array([[5, 5, 15, 15]])

bboxes1_xysr = np.array([[5, 5, 100, 1]])
bboxes2_xysr = np.array([[15, 15, 100, 1]])
bboxes3_xysr = np.array([[10, 10, 100, 1]])

def test_xyxy_to_xysr():
    tmp = xyxy_to_xysr(bboxes1_xyxy[0]).reshape(-1)
    assert np.allclose(tmp, bboxes1_xysr[0], atol=1e-6)

def test_xysr_to_xyxy():
    tmp = xysr_to_xyxy(bboxes1_xysr[0]).reshape(-1)
    assert np.allclose(tmp, bboxes1_xyxy[0], atol=1e-6)

def test_xyxy_to_xysr_and_back_identity():
    box_xysr = xyxy_to_xysr(bboxes1_xyxy[0])
    box_xyxy_back = xysr_to_xyxy(box_xysr)
    assert np.allclose(bboxes1_xyxy[0], box_xyxy_back, atol=1e-6)

def test_batch_conversion_xyxy_to_xysr():
    bboxes = np.stack([bboxes1_xyxy[0], bboxes2_xyxy[0], bboxes3_xyxy[0]])
    xysr = convert_bbox_xyxy_to_xysr_batch(bboxes)
    assert np.allclose(xysr, np.stack([bboxes1_xysr[0], bboxes2_xysr[0], bboxes3_xysr[0]]), atol=1e-6)

def test_batch_conversion_xysr_to_xyxy():
    bboxes = np.stack([bboxes1_xysr[0], bboxes2_xysr[0], bboxes3_xysr[0]])
    xyxy = convert_bbox_xysr_to_xyxy_batch(bboxes)
    assert np.allclose(xyxy, np.stack([bboxes1_xyxy[0], bboxes2_xyxy[0], bboxes3_xyxy[0]]), atol=1e-6)