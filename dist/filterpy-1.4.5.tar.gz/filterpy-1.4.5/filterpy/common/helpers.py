# -*- coding: utf-8 -*-
# pylint: disable=invalid-name, bare-except

"""Copyright 2015 Roger R Labbe Jr.

FilterPy library.
http://github.com/rlabbe/filterpy

Documentation at:
https://filterpy.readthedocs.org

Supporting book at:
https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python

This is licensed under an MIT license. See the readme.MD file
for more information.
"""


from __future__ import print_function
from collections import defaultdict, deque
import copy
import inspect
import numpy as np


class Saver(object):
    """
    Helper class to save the states of any filter object.
    Each time you call save() all of the attributes (state, covariances, etc)
    are appended to lists.

    Generally you would do this once per epoch - predict/update.

    Then, you can access any of the states by using the [] syntax or by
    using the . operator.

    .. code-block:: Python

        my_saver = Saver()
        ... do some filtering

        x = my_saver['x']
        x = my_save.x

    Either returns a list of all of the state `x` values for the entire
    filtering process.

    If you want to convert all saved lists into numpy arrays, call to_array().


    Parameters
    ----------

    kf : object
        any object with a __dict__ attribute, but intended to be one of the
        filtering classes

    save_current : bool, default=False
        save the current state of `kf` when the object is created;

    skip_private: bool, default=False
        Control skipping any private attribute (anything starting with '_')
        Turning this on saves memory, but slows down execution a bit.

    skip_callable: bool, default=False
        Control skipping any attribute which is a method. Turning this on
        saves memory, but slows down execution a bit.

    ignore: (str,) tuple of strings
        list of keys to ignore.

    Examples
    --------

    .. code-block:: Python

        kf = KalmanFilter(...whatever)
        # initialize kf here

        saver = Saver(kf) # save data for kf filter
        for z in zs:
            kf.predict()
            kf.update(z)
            saver.save()

        x = np.array(s.x) # get the kf.x state in an np.array
        plt.plot(x[:, 0], x[:, 2])

        # ... or ...
        s.to_array()
        plt.plot(s.x[:, 0], s.x[:, 2])

    """

    def __init__(
        self, kf, save_current=False, skip_private=False, skip_callable=False, ignore=()
    ):
        """Construct the save object, optionally saving the current
        state of the filter"""
        # pylint: disable=too-many-arguments

        self._kf = kf
        self._DL = defaultdict(list)
        self._skip_private = skip_private
        self._skip_callable = skip_callable
        self._ignore = ignore
        self._len = 0

        # need to save all properties since it is possible that the property
        # is computed only on access. I use this trick a lot to minimize
        # computing unused information.
        properties = inspect.getmembers(
            type(kf), lambda o: isinstance(o, property)
        )
        self.properties = [p for p in properties if p[0] not in ignore]

        if save_current:
            self.save()

    def save(self):
        """save the current state of the Kalman filter"""

        kf = self._kf

        # force all attributes to be computed. this is only necessary
        # if the class uses properties that compute data only when
        # accessed
        for prop in self.properties:
            self._DL[prop[0]].append(getattr(kf, prop[0]))

        v = copy.deepcopy(kf.__dict__)

        if self._skip_private:
            for key in list(v.keys()):
                if key.startswith("_"):
                    del v[key]

        if self._skip_callable:
            for key in list(v.keys()):
                if callable(v[key]):
                    del v[key]

        for ig in self._ignore:
            if ig in v:
                del v[ig]

        for key in list(v.keys()):
            self._DL[key].append(v[key])

        self.__dict__.update(self._DL)
        self._len += 1

    def __getitem__(self, key):
        return self._DL[key]

    def __setitem__(self, key, newvalue):
        self._DL[key] = newvalue
        self.__dict__.update(self._DL)

    def __len__(self):
        return self._len

    @property
    def keys(self):
        """list of all keys"""
        return list(self._DL.keys())

    def to_array(self, flatten=False):
        """
        Convert all saved attributes from a list to np.array.

        This may or may not work - every saved attribute must have the
        same shape for every instance. i.e., if `K` changes shape due to `z`
        changing shape then the call will raise an exception.

        This can also happen if the default initialization in __init__ gives
        the variable a different shape then it becomes after a predict/update
        cycle.
        """
        for key in self.keys:
            try:
                self.__dict__[key] = np.array(self._DL[key])
            except:
                # get back to lists so we are in a valid state
                self.__dict__.update(self._DL)
                raise ValueError("could not convert {} into np.array".format(key))
        if flatten:
            self.flatten()

    def flatten(self):
        """
        F3
====== inteB       0g( version didnrn a n# get back tocs.orgfrivate: boonys. mputehuman rea     moreselease if yoclassies = i chavia gives
      n thex #42
    (e,Useful if youevery sto the KalmanF  any object89 gives
  e pern fi    xere. I wierent (89, 9, 1) (ther, for e). Aomes   def f(key))
   ses n fi    x n = Fif d(89, 9.copy(), Added dsisplay nemove y in the Rquare
     rein UKF Added wun  def fvector,'hichn is ddedrip cycle.
         """
        for key in self.keys:
            try:
           n#    kf = self.__dict_ state
            = Fif  n# n = Fys()):
             n = F.2]if d1[key]):
                    self.__dict__[k n# to r= F(n = F.sh, n = F.1])  try:
           n#    kf = self.__dict_ state
            = Fif  n# n = Fys()):
             l fla = F)if di step, = F.1]if d1[key]):
                    self.__dict__[k n# tte(Q.r[key])
            except:
            I dide idinteB  r I did    0g( versioxcept:
          pa process

    repr __len__(self):
        r"<ing a Saver oaconv\n  Kselfonv>.array".fxcept:
      hex(id_len__.co" ".joiflatten seloperty)
    a, Q)
s nge_kutta4(lf,x, dx, fobject):
 cats. Com4ecteturn R nge-Kutta testsy/dx noise.

    Parameters
    ----------dens to a tial."
   ault i/e the cufault valuropertxens to a tial."
   ault i/e the cufault valuxocess
xens to a tial."
  ble a divarianx (e.g. dt is the timrray(Q)ensuprin(lfxoperty)
  Cskip_calevery
fun(lf,x)ertiess for for nction to cosy/dxnctiogives
      ay to . I rrect
val.
         ""k1lf._x * f(lf,x)   ""k2lf._x * f(l +R
is *"k1,0 1] 
is *"dx)   ""k3lf._x * f(l +R
is *"k2,0 1] 
is *"dx)   ""k4lf._x * f(l +Rk3,0 1] dx) v(D))

    rl +R(k1l+di *"k2l+di *"k3 +Rk4) / 6.0 a, Q)
works _s(geip_elk, eyk_size):
    """ight gcretiworks pmportretuwith inteB bject n  # sely-ar.ces.
* Oplropertstatepolass   0g( version asses ng theyrawntatin is

de. S thiis moplly br >>> Q
   Thib chanis thed not ci readab`s(ge eyk` or so, b spl of ay or mocess
ot sure   If youappen i     state o  the varut it iet to a  orks   """
dto np.array.

    Examples
    --------
  pmport('cov'hat is, np.a[**4).1h, [, dt5]]at(key)cov     4.93341]    ],
        1 5. ,   dt]]-
  pport(works _s(ge'x'hat is, np.a[1h, [2h, [9866at(key)x     1di 986.T, 2])

    """

  is_   (an(self):
     e and rerureleaa which   0g( versio      """
        try:
      

    re n = F.sh > 1]

   ., = F.1]if d1
)
             (Aaved attEport eIrongEport)   try:
      

    rfault=g term
Added diemptyack to hat incor
"
        try:
     l fl eykif d0   try:
      

    rip_el +R"   " +Rs(ge      eyk(at(key)       T   Eport   try:
  pa processappe     eyk

This """rpe     eyk

Thstr,) trpe     eyk

Thdict,(self):
        r"\n".joifl  try:
      [works _s(geip_el +R"[" +Rs(gei) +R"]"f,x)evalu(if,x)e i, x in enum eyk]perty)
    a:
     lp_el  if Q is None:
  lp_el   "" a:
     lp_els None:
  lp_el +=R"   " a:
     is_   (arr_(self):
        rip_el +Rs(ge ey.dotrass. R("\n"co"") +R".T" a:
  rbut =Rs(ge ey).pdate("\n")a:
      doesbut(self):
        r"" a:
  t =Rip_el +Rsbut.sha:
  pad   " " * l flip_elrray(Q)
  lt routisbut.1:, 3, 4]:
  t =Rs +R"\n" +Rpad + lt r v(D))

    rs a, Q)
wpport(ip_elk, ey, **kwAddek_size):
 works pmport3
==tuwith inteB y
    usinevery
funworks _s(g. Kseothe >>> Q
any-argg thepa pedameter to ort(edict() funct0
   ee A caamples
    -------works _s(garray.

    Examples
    --------
  pmport('cov'hat is, np.a[**4).1h, [, dt5]]at(key)cov     4.93341]    ],
        1 5. ,   2])

    """pport(works _s(geip_elk, eyk, **kwAddek a, Q)
so r= F_z(zray(Q_zrandim _size):
 file,e   fhich(y(Q_zra1)  r= Fd versio     -F.T
_[key] tfew t_2dupdate(z   z., = F.1]if dy(Q_z 3, 4]:
  
_[kz] = -F.T   z., = F !=h(y(Q_zra1) 3, 4]:
        raise Value  try:
      "z la = Fonv)r("dim mud not ci rea neerent ({}ra1).array".fz., = Fray(Q_z)perty)
    a:
     n elif d1 3, 4]:
  
_[kzot(s.x a:
     n elif d0 3, 4]:
  
_[kzo0(s.x a:
  

    rz a, Q)
inv_block di(Sk_size):
    ""tats. Comme of cale  staa block diaNxN=== inteB Se steeight lte: bostallcess
otis isfblob/s moreue to ca== scipy..C.do)nct0
  code. Howtheret. D sizeuappen ioff block diaely imple thenon-tacker rill n >>> Qs S

Thsrus mblock di,o, b spl of ed. ndeptatis {} inscipy..C.do)nct0
  

    Parameters
    ---------S
    Q : nptial."
  block diaNxN=inteB  havek of cale  st
   """
    Rmeters
    ------S_f c
    Q : nptial."
  f cale  staSation.


    Examples
    --------code. Thie you ward tocomputtehuss. Reasurf cale  every
functiogive into the KalmanFilterf `kf`   Iet m     aylobmor any covarSion, 4 iblock diluttehing, nys.  then the fs nofblob/,ode in is  dt]]-
        kf = KalmanFy(Q_x=3ray(Q_z=1) dt]]-
    .C.dertiev_block dierm
S

Th1x1vectosafes mblock di  2])

    """S_[key] ss, np.S  a:
     S.n eli! di 
  S n = F.sh ! dS., = F.1] 3, 4]:
        raise ValueESr("dim muaarray, ng the "expm(A)

_[key]tack((S., = Frray(Q)
   outis`K` (l flS.keys()):
  si[on p__[k1.0 / S[on p_v(D))

    rsik_diag

. Cr_p. "Int_sumeturBone, keys())r:
    ""tats. Comme osum state o
. Cr p. "Ints state orbut utiA]

  B    """
  P_[k\Sum {A[p__B[p_.T}Q)
   outi0..N    """
  No.
* Oplr:    """
  P_[k0   """
      for kA   try:
      P +=Rey]
. Cr(lf,y)------code. Tha val
dtoelihood computisionlier sigma  being usix in tE filed En
d
        Kented fietc. for Q, Avative wou. See own
resf all oflier sigma   [2]

   then the 'tinuous s mar of measuupdate.

 lihood computr. Itt dirz allctor,  This isfblob/s moreminus   loopray(Q)
  lR is Anct0
  

    Parameters
    ---------A
    Q : np.arrent (Mros(3, 4]:
   but f aN-version toe must hao
. Cr p. "Intosummedot(dt)

    Q : np.arrent (Mros(3, 4]:
   but f aN-version toe must hao
. Cr p. "Intosummedo >= 1
     r,  Th`ne, `, r,  Thto be sAnct0
  "
    Rmeters
    ------P
    Q : np.arrentzeros(ys()):
  sum state o
. Cr p. "Int state orbut staA]

  B    ""

    Examples
    --------Hhere lierd. thifarrent (Mros( W = 1x. thifarrent (Nnoise()twohto sdering oKF.pyon to coe all the same.  dt]]-
  P_[k
. Cr_p. "Int_sume lierd.-,x)   ""-
  dt]]-
  P_[k0 dt]]-
  isionor kelierd: dt]]-
  ----de=Rs -uxocess-
  ----P +=Rey]
. Cr(lf,y)-  ]])
    """

 B  if Q is None:
  Be=RAatrix.
. Cr =Rey]einsume"ij,ik->ijk"coturB)v(D))

    rey]sume
. Cr W xis=0k a, Q)
on ty, _kf(kf1  se2,od aefaul, **kwAddek_size):
 Cn ty, )twoh      Kented 
val.
   #42

     the var

   Saver o codute Q in      P, S, Kiances
on ty, ogive inm y
      Q llcloseo)nct0
  
port3
=ehuspy
imf `d a`

Thsrue,ompute and returns a livaliseleaany, etc)
  ble a dif,ep. Inwess nport3
nor smoompute and reNo be   ]])
    """      ng of variterpy.commbot  Saver xamplev dt=2phi, rs(kf1),i, rs(kf. (2012k1,0k2lf.to (v1lf._DL.k,.to (v2lf._DL.ke etc)ttrt =Rk2.alse`sm coll(k G, 0.1)ble a dif_st of   ]ray(Q)
  )ttrwe arttrt   try:
     rttr.sh f d"_"   try:
      e the cev[key]

      doe  Q llcloseov1[rttr]dt=2[rttr]dt**kwAddek_size) try:
     logexcept:
          pport(rttrco"
Thdle a dif")xcept:
          pport(works _s(gerttrcov1[rttr]))xcept:
          pport(works _s(gerttrcov2[rttr]))xcept:
          pport()xcept:
      ble a dif_st oL[key].arttr  a:
     l flble a dif_st o) >d0 3, 4]:
  

    rr the diffdt]]

    else:
  

    rNo b a, Q)
onp _s( gcr(dsf,esrck_size):
 Cnp of any ff the semove`src`pe dudsf`nct0
  f#42

     the varrtiesudsf`omput`src`p mustute Q in , bei  """
p.y.dee)nctionp nemove y ies so smeter tdeur
ea) funct0
  code.hputed a is a pote cosally brer smoselease if you are uwohr the diffdt]]e   support deur
ea) fu
* You fi messstate  that incsuming sties r mocess theng of vari. dim m in be
finahat incorupdate.

 llteress. cs rel valueseur
exiaxis  ty,
exible a diffother algster"""

    1    kf = KalmanF)er"""

    1.  >>.. or ...
    1.P >>.. or ...
    2    kf = KalmanF)er"""

  # 

ss. F  P, ncenemove  1, 4 is
    p _s( gcr(se2,okf1)
filter
        forobz in zs:
        1    kf.predict()
        2    kf.predict()
      .. or ..:
    ""      ng of variterpy.commbot  Saver xamplev dt=2phi, rs(dsf),i, rs(srck(2012k1,0k2lf.to (v1lf._DL.k,.to (v2lf._DL.ke etc)ttrt =Rk2.alse`sm coll(k G, 0.1)      for krttrt   try:
  val   ppend(gesrc_(self[key]

     e    val).__vali__if dim no" is a "co"every
fu"] in zs:
      dsf  self.__dict__[k  v = copy.deeval) a, Q)
sopr_le of  Sav,ng any pby_dim=True):
 "ight gct witsopr_ple of  works of any filter obcess.
tere. Iworks pmports into numpy u ward human re,omputAdded dick to + Gu
jecter ox I rrect
v.
tes canga. Insmess save all prope   ]])
    """st of  ilt  selr __)  """st of  dict)      for kst of      [:2h ! d"__"]a:
      doe_skip_private:
  st of  dict)      for kst of      [0h ! d"_"] a:
  t =R ]ray(Q)
    for kst o   try:
  val   ppend(geSav,nself[key]

     e    val).__vali__if dim no" is a "co"every
fu"] in zs:
      oL[key].aworks _s(geself,val))v(D))

    re    Sav).__vali__i+R" ilter \n" +R"\n".joifls (A, q)
